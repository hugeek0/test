from setuptools import setup

setup(name='fixer',
      version='1.0',
      description='fixer is a package for get rates from web',
      author='mhmd',
      author_email='*****@gmail.com',
      packages=['fixer'],
      install_requires=['requsets'],
      )
